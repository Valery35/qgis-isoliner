# -*- coding: utf-8 -*-
#
# Isoliner - грид и изолинии (QGIS).
# © 2026 ООО «Информ++» (www.informpp.ru).
# SPDX-License-Identifier: GPL-2.0-or-later
#
# Тесты ядра отчёта по створу. Синтетический рельеф, эталонные цифры
# посчитаны руками:
#     python grid_isolines/tests/test_topo_gauge.py
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", ".."))

from grid_isolines import topo_flow, topo_gauge as tg  # noqa: E402

CELL = 10.0  # м


def _ramp():
    """Наклонная плоскость: вода течёт строго на восток вдоль строк.

    z падает с ростом столбца, ряды независимы. Аккумуляция в ячейке
    (r, c) равна c + 1, главный водоток от восточного края - вся строка.
    """
    ny, nx = 4, 6
    z = np.tile(np.arange(nx, 0, -1, dtype=np.float64), (ny, 1))  # 6..1
    _, down = topo_flow.d8_directions(z)
    acc = topo_flow.flow_accumulation(down, (ny, nx))
    return z, down, acc, (ny, nx)


def _valley():
    """V-долина с осевым водотоком по среднему столбцу, сток на юг.

    z = |c - 2| * 10 - r: бока круче оси, ось падает к югу. Весь грид
    стекает в низ среднего столбца.
    """
    ny, nx = 5, 5
    r = np.arange(ny, dtype=np.float64)[:, None]
    c = np.arange(nx, dtype=np.float64)[None, :]
    z = np.abs(c - 2) * 10.0 - r
    _, down = topo_flow.d8_directions(z)
    acc = topo_flow.flow_accumulation(down, (ny, nx))
    return z, down, acc, (ny, nx)


# --- притяжка ------------------------------------------------------------

def test_snap_to_max_acc():
    z, down, acc, shape = _ramp()
    # точка на середине строки 1, радиус 2 ячейки: максимум в окне - самый
    # восточный столбец. Ряды одинаковы, максимумы равны, берётся первый по
    # обходу окна - верхняя строка окна (документированный детерминизм)
    r, c = tg.snap_to_max_acc(acc, 1, 3, 2)
    assert (r, c) == (0, 5)
    # радиус 0: без притяжки
    assert tg.snap_to_max_acc(acc, 1, 3, 0) == (1, 3)
    # выход за край зажимается
    assert tg.snap_to_max_acc(acc, -5, 99, 0) == (0, 5)


def test_snap_deterministic_on_ties():
    acc = np.zeros((3, 3))
    acc[0, 1] = 7.0
    acc[2, 1] = 7.0
    # равные максимумы: берётся первый по обходу окна (верхний)
    assert tg.snap_to_max_acc(acc, 1, 1, 1) == (0, 1)


# --- бассейн и зональная статистика --------------------------------------

def test_basin_mask_ramp():
    z, down, acc, shape = _ramp()
    ny, nx = shape
    # створ на восточном краю строки 2: бассейн - ровно эта строка
    seed = 2 * nx + (nx - 1)
    mask = tg.basin_mask(down, shape, seed)
    assert int(mask.sum()) == nx
    assert mask[2].all() and not mask[1].any() and not mask[3].any()


def test_basin_mask_valley_full_grid():
    z, down, acc, shape = _valley()
    ny, nx = shape
    seed = (ny - 1) * nx + 2  # низ оси долины
    mask = tg.basin_mask(down, shape, seed)
    assert int(mask.sum()) == ny * nx  # весь грид стекает через створ
    assert int(acc[ny - 1, 2]) == ny * nx


def test_zonal_stats_nodata_and_empty():
    v = np.array([[1.0, 2.0], [3.0, float("nan")]])
    mask = np.ones((2, 2), dtype=bool)
    mean, vmin, vmax = tg.zonal_stats(v, mask)
    assert (mean, vmin, vmax) == (2.0, 1.0, 3.0)  # nan исключён
    nodata = np.array([[False, True], [False, True]])
    mean, vmin, vmax = tg.zonal_stats(v, mask, nodata)
    assert (mean, vmin, vmax) == (2.0, 1.0, 3.0)
    assert tg.zonal_stats(v, np.zeros((2, 2), dtype=bool)) == (
        None, None, None)


# --- главный водоток ------------------------------------------------------

def test_trace_ramp_row():
    z, down, acc, shape = _ramp()
    ny, nx = shape
    seed = 1 * nx + (nx - 1)
    length, path = tg.trace_main_stream(down, acc, shape, seed, CELL)
    # вся строка: 5 шагов по 10 м, путь от створа к истоку
    assert abs(length - (nx - 1) * CELL) < 1e-9
    assert path[0] == seed and path[-1] == 1 * nx + 0
    assert len(path) == nx


def test_trace_valley_axis():
    z, down, acc, shape = _valley()
    ny, nx = shape
    seed = (ny - 1) * nx + 2
    length, path = tg.trace_main_stream(down, acc, shape, seed, CELL)
    # вверх по оси долины 4 шага, а с верха оси трасса правильно уходит в
    # сильнейший приток (боковые ячейки строки 0) до ячейки без притоков:
    # водоток ведётся до истока, всего 6 шагов по 10 м
    assert abs(length - 6 * CELL) < 1e-9
    assert [p % nx for p in path] == [2, 2, 2, 2, 2, 3, 4]
    assert path[-1] == 4  # исток: угловая ячейка без притоков


def test_trace_stops_at_source():
    z, down, acc, shape = _ramp()
    ny, nx = shape
    # створ в истоке (западный столбец): пути нет, длина ноль
    length, path = tg.trace_main_stream(down, acc, shape, 0, CELL)
    assert length == 0.0 and path == [0]


# --- сборный отчёт --------------------------------------------------------

def test_gauge_report_ramp_hand_numbers():
    z, down, acc, shape = _ramp()
    ny, nx = shape
    seed = 2 * nx + (nx - 1)
    rep = tg.gauge_report(z, down, acc, shape, seed, CELL)
    # площадь: 6 ячеек по 100 м² = 600 м² = 0.0006 км²
    assert abs(rep["area_km2"] - 6 * CELL * CELL / 1e6) < 1e-12
    assert rep["cells"] == nx
    # высоты строки: 6..1
    assert (rep["z_min"], rep["z_max"]) == (1.0, 6.0)
    assert abs(rep["z_mean"] - 3.5) < 1e-12
    assert rep["z_gauge"] == 1.0
    # водоток: 50 м, падение 6 - 1 = 5 м, уклон 100 промилле
    assert abs(rep["stream_km"] - 0.05) < 1e-12
    assert abs(rep["stream_fall_m"] - 5.0) < 1e-12
    assert abs(rep["stream_ppm"] - 100.0) < 1e-9
    # уклон бассейна не подавали - None, а не ноль
    assert rep["slope_mean"] is None


def test_gauge_report_valley_with_slope():
    z, down, acc, shape = _valley()
    ny, nx = shape
    seed = (ny - 1) * nx + 2
    slope = np.full(shape, 2.5)
    rep = tg.gauge_report(z, down, acc, shape, seed, CELL, slope=slope)
    assert rep["cells"] == ny * nx
    assert abs(rep["slope_mean"] - 2.5) < 1e-12
    # трасса до истока (0, 4): z от -4 (створ) до 20, падение 24 м на 60 м
    assert abs(rep["stream_fall_m"] - 24.0) < 1e-12
    assert abs(rep["stream_km"] - 0.06) < 1e-12
    assert abs(rep["stream_ppm"] - 400.0) < 1e-9
    assert rep["z_gauge"] == -4.0


def test_gauge_report_nodata_excluded():
    z, down, acc, shape = _ramp()
    ny, nx = shape
    nodata = np.zeros(shape, dtype=bool)
    nodata[2, 0] = True  # исток строки выключен из статистики
    seed = 2 * nx + (nx - 1)
    rep = tg.gauge_report(z, down, acc, shape, seed, CELL,
                          nodata_mask=nodata)
    assert rep["cells"] == nx - 1
    assert rep["z_max"] == 5.0  # ячейка с z=6 в nodata


def test_report_lines():
    z, down, acc, shape = _ramp()
    seed = 2 * shape[1] + (shape[1] - 1)
    rep = tg.gauge_report(z, down, acc, shape, seed, CELL)
    lines = tg.report_lines(rep)
    assert len(lines) == 2
    assert "0.001" in lines[0] and "1.00...6.00" in lines[0]
    assert "100.0" in lines[1]
    # переводчику отдаются шаблоны, тождественный ничего не меняет
    seen = []
    assert tg.report_lines(rep, lambda t: (seen.append(t) or t)) == lines
    assert any("%s" in t for t in seen)


def test_report_keys_order_stable():
    assert tg.REPORT_KEYS[0] == "area_km2"
    assert tg.REPORT_KEYS[-1] == "cells"
    assert len(set(tg.REPORT_KEYS)) == len(tg.REPORT_KEYS)


# --- линейный водосбор (канава) -------------------------------------------

def _grid_geo():
    """Геопривязка для тестовых гридов: начало (0, 0), ячейка 10 м, ось Y
    вниз, как в GeoTIFF."""
    return 0.0, 0.0, CELL


def test_cells_along_polyline_straight():
    ox, oy, cell = _grid_geo()
    # линия вдоль строки 1 через весь грид 4x6
    verts = [(5.0, -15.0), (55.0, -15.0)]
    got = tg.cells_along_polyline(verts, ox, oy, cell, (4, 6))
    assert got == [1 * 6 + c for c in range(6)]


def test_cells_along_polyline_diagonal_no_gaps():
    ox, oy, cell = _grid_geo()
    verts = [(5.0, -5.0), (45.0, -45.0)]      # по диагонали
    got = tg.cells_along_polyline(verts, ox, oy, cell, (5, 5))
    assert got == [0, 6, 12, 18, 24]          # без пропусков


def test_cells_along_polyline_clips_and_dedups():
    ox, oy, cell = _grid_geo()
    # уходит за левый край и возвращается: наружные точки отброшены
    verts = [(-100.0, -15.0), (25.0, -15.0), (25.0, -15.0)]
    got = tg.cells_along_polyline(verts, ox, oy, cell, (4, 6))
    assert got == [1 * 6 + 0, 1 * 6 + 1, 1 * 6 + 2]
    assert len(got) == len(set(got))          # повторов нет


def test_cells_in_polygon_square():
    """Квадрат 3x3 ячейки: внутренность строчной развёрткой, контур в тех
    же ячейках, ничего лишнего."""
    ox, oy, cell = _grid_geo()
    ny, nx = 6, 6
    # x 22..48, y -48..-22: центры ячеек 25/35/45 внутри по обеим осям
    ring = [(22, -22), (48, -22), (48, -48), (22, -48), (22, -22)]
    got = set(tg.cells_in_polygon([ring], ox, oy, cell, (ny, nx)))
    want = {r * nx + c for r in range(2, 5) for c in range(2, 5)}
    assert got == want


def test_cells_in_polygon_tiny_boundary_only():
    """Полигон меньше ячейки: ни один центр не внутри, ячейку даёт контур."""
    ox, oy, cell = _grid_geo()
    ring = [(21, -21), (23, -21), (23, -23), (21, -23)]
    got = tg.cells_in_polygon([ring], ox, oy, cell, (6, 6))
    assert got == [2 * 6 + 2]


def test_cells_in_polygon_clips_to_grid():
    """Кольцо шире грида: наружные ячейки отбрасываются, дублей нет."""
    ox, oy, cell = _grid_geo()
    ny, nx = 3, 3
    ring = [(-50, 50), (80, 50), (80, -80), (-50, -80)]
    got = tg.cells_in_polygon([ring], ox, oy, cell, (ny, nx))
    assert sorted(got) == list(range(ny * nx))
    assert len(got) == len(set(got))


def test_polygon_seed_catchment_over_depression():
    """Затравка карьера внутренностью: снаружи трассировка по реальному
    рельефу, внутри залитой ямы условные направления не мешают.

    Канал рядов 2..4 падает на запад и огорожен гребнями в рядах 1 и 5,
    в середине канала (столбцы 2..4) вырыта яма глубиной 5. После
    заполнения вода канала восточнее ямы идёт на запад сквозь неё,
    гребни сливаются в канал по прямой, ряды 0 и 6 идут мимо, всё
    западнее ямы лежит ниже по стоку и в водосбор не входит.
    """
    ox, oy, cell = _grid_geo()
    ny, nx = 7, 7
    c = np.arange(nx, dtype=np.float64)[None, :]
    z = np.tile(c * 0.1, (ny, 1))
    z[1, :] += 100.0
    z[5, :] += 100.0
    z[0, :] += 0.05     # крайние ряды чуть выше, чтобы гребень
    z[6, :] += 0.05     # сливался в канал без ничьих по уклону
    z[2:5, 2:5] -= 5.0
    from grid_isolines import hydro_fill
    zf, _n, _m = hydro_fill.fill_depressions(z, epsilon=1e-3)
    _, down = topo_flow.d8_directions(zf)
    ring = [(22, -22), (48, -22), (48, -48), (22, -48)]
    seeds = tg.cells_in_polygon([ring], ox, oy, cell, (ny, nx))
    assert set(seeds) == {r * nx + cc for r in range(2, 5)
                          for cc in range(2, 5)}
    m = tg.catchment_mask(down, (ny, nx), seeds)
    want = np.zeros((ny, nx), dtype=bool)
    want[2:5, 2:5] = True     # сама затравка
    want[2:5, 5:] = True      # канал восточнее ямы
    want[1, 2:] = True        # гребни сливаются в канал по прямой на юг
    want[5, 2:] = True        # и на север, восточнее западного края ямы
    assert (m == want).all()


def test_ditch_report_seed_km2():
    z, down, acc, shape = _valley()
    nx = shape[1]
    seeds = [3 * nx + c for c in range(nx)]
    rep = tg.ditch_report(z, down, shape, seeds, CELL)
    assert abs(rep["seed_km2"] - nx * CELL * CELL / 1e6) < 1e-12
    assert "seed_km2" in tg.DITCH_KEYS
    assert len(set(tg.DITCH_KEYS)) == len(tg.DITCH_KEYS)


def test_burn_sloped_bottom_is_monotone_to_outfall():
    """Дно жёлоба монотонно падает к стоку, перевала через борт нет.

    Приём Иванова: постоянная глубина на волнистом рельефе даёт дно,
    которое поднимается по ходу трассы, и вода переваливает. Жёлоб обязан
    это исключить.
    """
    ox, oy, cell = _grid_geo()
    ny, nx = 3, 10
    # волнистый профиль вдоль ряда 1: вниз, потом горб
    z = np.zeros((ny, nx))
    z[1, :] = [10, 9, 8, 9.5, 11, 8, 7, 8.5, 6, 5]
    run = [1 * nx + c for c in range(nx)]
    out = tg.burn_trace_sloped(z, [run], depth=1.0, slope=0.01, cell=cell)
    bottom = out.ravel()[np.asarray(run)]
    # сток к концу (правый край ниже), падение строго монотонное
    assert (np.diff(bottom) <= -0.01 * cell + 1e-12).all()
    # дно нигде не выше исходной врезки
    assert (bottom <= z[1, :] - 1.0 + 1e-12).all()
    # чужие ячейки не тронуты
    assert (out[0, :] == z[0, :]).all() and (out[2, :] == z[2, :]).all()


def test_burn_sloped_direction_follows_low_end():
    """Направление стока выбирается по нижнему концу трассы."""
    ox, oy, cell = _grid_geo()
    nx = 8
    z = np.zeros((1, nx))
    z[0, :] = np.linspace(2.0, 9.0, nx)   # низкий конец слева
    run = list(range(nx))
    out = tg.burn_trace_sloped(z, [run], depth=0.5, slope=0.01, cell=cell)
    bottom = out.ravel()[np.asarray(run)]
    assert (np.diff(bottom) >= 0.01 * cell - 1e-12).all()  # падает к началу


def test_burn_sloped_zero_slope_still_monotone():
    """Нулевой уклон даёт бегущий минимум: рост дна запрещён и без него."""
    ox, oy, cell = _grid_geo()
    z = np.array([[5.0, 3.0, 6.0, 2.0]])
    run = [0, 1, 2, 3]
    out = tg.burn_trace_sloped(z, [run], depth=1.0, slope=0.0, cell=cell)
    bottom = out.ravel()[np.asarray(run)]
    assert (np.diff(bottom) <= 1e-12).all()
    assert bottom[-1] == 1.0


def test_burn_sloped_nodata_and_degenerate():
    ox, oy, cell = _grid_geo()
    z = np.array([[5.0, 4.0, 3.0]])
    mask = np.array([[False, True, False]])
    out = tg.burn_trace_sloped(z, [[0, 1, 2]], 1.0, 0.01, cell,
                               nodata_mask=mask)
    assert out[0, 1] == 4.0            # nodata не тронута
    assert out[0, 0] == 4.0 and out[0, 2] <= 2.0
    # пустые входы - копия без изменений
    assert (tg.burn_trace_sloped(z, [], 1.0, 0.01, cell) == z).all()
    assert (tg.burn_trace_sloped(z, [[0]], 0.0, 0.01, cell) == z).all()


def test_polyline_length():
    assert abs(tg.polyline_length([(0, 0), (30, 40)]) - 50.0) < 1e-9
    assert tg.polyline_length([(0, 0)]) == 0.0


def test_catchment_of_line_across_valley():
    """Канава поперёк долины перехватывает всё, что выше неё по стоку."""
    z, down, acc, shape = _valley()
    ny, nx = shape
    seeds = [3 * nx + c for c in range(nx)]   # трасса вдоль строки 3
    mask = tg.catchment_mask(down, shape, seeds)
    # строки 0..3 стекают в трассу, нижняя строка 4 уже ниже неё
    assert mask[:4].all()
    assert not mask[4].any()
    assert int(mask.sum()) == 4 * nx


def test_catchment_of_single_cell_matches_gauge():
    """Линейный водосбор из одной ячейки совпадает с точечным створом."""
    z, down, acc, shape = _ramp()
    ny, nx = shape
    seed = 2 * nx + (nx - 1)
    m_line = tg.catchment_mask(down, shape, [seed])
    m_point = tg.basin_mask(down, shape, seed)
    assert (m_line == m_point).all()


def test_catchment_empty_seeds():
    z, down, acc, shape = _ramp()
    assert tg.catchment_mask(down, shape, []).sum() == 0


def test_burn_trace_lowers_only_trace():
    z, down, acc, shape = _valley()
    ny, nx = shape
    seeds = [3 * nx + c for c in range(nx)]
    zb = tg.burn_trace(z, seeds, 5.0)
    assert (zb[3] == z[3] - 5.0).all()
    assert (zb[0] == z[0]).all()
    assert z[3][0] != zb[3][0]                # исходный массив не тронут


def test_burn_trace_respects_nodata_and_zero_depth():
    z, down, acc, shape = _valley()
    ny, nx = shape
    seeds = [3 * nx + c for c in range(nx)]
    nod = np.zeros(shape, dtype=bool)
    nod[3, 0] = True
    zb = tg.burn_trace(z, seeds, 5.0, nodata_mask=nod)
    assert zb[3, 0] == z[3, 0]                # nodata не трогаем
    assert zb[3, 1] == z[3, 1] - 5.0
    assert (tg.burn_trace(z, seeds, 0.0) == z).all()


def test_ditch_report_hand_numbers():
    z, down, acc, shape = _valley()
    ny, nx = shape
    seeds = [3 * nx + c for c in range(nx)]
    slope = np.full(shape, 1.5)
    rep = tg.ditch_report(z, down, shape, seeds, CELL,
                          trace_len=(nx - 1) * CELL, slope=slope)
    assert rep["cells"] == 4 * nx
    assert abs(rep["area_km2"] - 4 * nx * CELL * CELL / 1e6) < 1e-12
    assert rep["trace_cells"] == nx
    assert abs(rep["trace_km"] - 0.04) < 1e-12
    assert abs(rep["slope_mean"] - 1.5) < 1e-12
    # высоты только по водосбору: строки 0..3 долины
    assert rep["z_max"] == 20.0 and rep["z_min"] == -3.0


def test_ditch_report_nodata_excluded():
    z, down, acc, shape = _valley()
    ny, nx = shape
    seeds = [3 * nx + c for c in range(nx)]
    nod = np.zeros(shape, dtype=bool)
    nod[0, :] = True
    rep = tg.ditch_report(z, down, shape, seeds, CELL, nodata_mask=nod)
    assert rep["cells"] == 3 * nx


def test_ditch_report_lines():
    z, down, acc, shape = _valley()
    nx = shape[1]
    seeds = [3 * nx + c for c in range(nx)]
    rep = tg.ditch_report(z, down, shape, seeds, CELL, trace_len=40.0)
    lines = tg.ditch_report_lines(rep)
    assert len(lines) == 2
    assert "0.002" in lines[0]
    assert "0.040" in lines[1] and "ячеек трассы 5" in lines[1]
    seen = []
    assert tg.ditch_report_lines(rep, lambda t: (seen.append(t) or t)) == lines
    assert any("%s" in t for t in seen)


def _run():
    fns = [(n, f) for n, f in sorted(globals().items())
           if n.startswith("test_") and callable(f)]
    bad = 0
    for name, fn in fns:
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            bad += 1
            print("FAIL %s: %s" % (name, exc))
    print("%d тестов, ошибок %d" % (len(fns), bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(_run())


# --- отчёт по готовому водосбору -------------------------------------------

def _slope_dem(ny=40, nx=40):
    """Наклонная плоскость с ложбиной: сток строго на юг."""
    Y, X = np.mgrid[0:ny, 0:nx]
    z = (200.0 - Y * 1.0 + np.abs(X - nx // 2) * 0.4).astype(float)
    downstream = np.full(ny * nx, -1, dtype=np.int64)
    for r in range(ny - 1):
        for c in range(nx):
            downstream[r * nx + c] = (r + 1) * nx + c
    acc = np.cumsum(np.ones((ny, nx)), axis=0)
    return z, downstream, acc


def test_mask_report_counts_the_given_polygon():
    """Площадь считается по ЗАДАННОЙ маске, а не по построенной заново.

    В этом весь смысл отдельного расчёта: водосбор пришёл извне, границы
    чужие, и менять их нельзя - иначе ответ будет про другой водосбор.
    """
    z, downstream, acc = _slope_dem()
    mask = np.zeros(z.shape, dtype=bool)
    mask[5:35, 10:30] = True
    rep = tg.mask_report(z, mask, 100.0, downstream=downstream, acc=acc)
    assert rep["cells"] == 30 * 20
    assert abs(rep["area_km2"] - 30 * 20 * 100.0 ** 2 / 1e6) < 1e-9


def test_mask_report_works_without_a_flow_grid():
    """Без решётки стока площадь и отметки считаются, длина нет.

    Половина ответа лучше отказа: галочка длины водотока снимается ради
    скорости, и остальное обязано посчитаться.
    """
    z, _d, _a = _slope_dem()
    mask = np.zeros(z.shape, dtype=bool)
    mask[5:35, 10:30] = True
    rep = tg.mask_report(z, mask, 100.0)
    assert rep["area_km2"] > 0 and rep["z_mean"] is not None
    assert rep["stream_km"] is None and rep["stream_fall_m"] is None


def test_outlet_prefers_accumulation_over_the_lowest_point():
    """Замыкание берётся по аккумуляции, а не по наименьшей отметке.

    Низшая точка может лежать в яме внутри площади или на краю,
    задевшем соседнюю долину, и водоток потянулся бы не туда.
    """
    z, _d, acc = _slope_dem()
    mask = np.zeros(z.shape, dtype=bool)
    mask[5:35, 10:30] = True
    # яма в середине: самая низкая точка, но аккумуляции там нет
    z[20, 20] = -500.0
    by_acc = tg.outlet_in_mask(z, mask, acc)
    by_low = tg.outlet_in_mask(z, mask, None)
    assert by_low == 20 * z.shape[1] + 20, "проверка потеряла смысл"
    assert by_acc != by_low, "яма перебила аккумуляцию"


def test_outlet_returns_none_for_an_empty_mask():
    z, _d, acc = _slope_dem()
    empty = np.zeros(z.shape, dtype=bool)
    assert tg.outlet_in_mask(z, empty, acc) is None


def test_stream_is_cut_by_the_polygon_boundary():
    """Длина водотока считается внутри полигона, а не по всей трассе.

    Трасса от замыкания может уйти далеко за границу заданного
    водосбора, и её полная длина отвечала бы на другой вопрос.
    """
    z, downstream, acc = _slope_dem()
    small = np.zeros(z.shape, dtype=bool)
    small[5:15, 10:30] = True
    big = np.zeros(z.shape, dtype=bool)
    big[5:35, 10:30] = True
    r_small = tg.mask_report(z, small, 100.0, downstream=downstream, acc=acc)
    r_big = tg.mask_report(z, big, 100.0, downstream=downstream, acc=acc)
    assert r_small["stream_km"] is not None and r_big["stream_km"] is not None
    assert r_small["stream_km"] < r_big["stream_km"]


def test_empty_mask_gives_zero_area_not_a_crash():
    z, downstream, acc = _slope_dem()
    rep = tg.mask_report(z, np.zeros(z.shape, dtype=bool), 100.0,
                         downstream=downstream, acc=acc)
    assert rep["cells"] == 0 and rep["area_km2"] == 0.0


# --- расчёт по СП 33-101 ---------------------------------------------------

def test_sp_slope_equals_half_the_tangent_on_a_plane():
    """Iск по СП на плоскости даёт половину тангенса уклона.

    Формула Iск = h·Σli/(2A) эмпирическая и НЕ возвращает физический
    уклон: двойка в знаменателе учитывает двусторонность склонов - вода
    стекает к водотоку с обоих бортов долины. Проверка держит это
    свойство: если оно уйдёт, значит формулу переписали не ту.
    """
    ny = nx = 200
    cell = 10.0
    s = math.tan(math.radians(5.0))
    y, _x = np.mgrid[0:ny, 0:nx]
    z = (y * cell * s).astype(float)
    mask = np.ones(z.shape, dtype=bool)
    area = ny * nx * cell * cell
    for interval in (1.0, 10.0):
        iso = tg.contour_length_in_mask(z, mask, cell, interval)
        got = tg.sp_slope_ppm(iso, area, interval)
        assert abs(got - s * 500.0) < s * 500.0 * 0.05, (
            "сечение %.0f: %.1f вместо %.1f" % (interval, got, s * 500.0))


def test_sp_slope_is_not_the_physical_slope():
    """Явная проверка того, что величины разные.

    Их легко перепутать, а разница вдвое: в нормативный отчёт нужна одна,
    в физический анализ другая.
    """
    ny = nx = 100
    cell = 10.0
    s = math.tan(math.radians(10.0))
    y, _x = np.mgrid[0:ny, 0:nx]
    z = (y * cell * s).astype(float)
    mask = np.ones(z.shape, dtype=bool)
    iso = tg.contour_length_in_mask(z, mask, cell, 5.0)
    sp = tg.sp_slope_ppm(iso, ny * nx * cell * cell, 5.0)
    assert abs(sp - s * 1000.0) > s * 300.0, "СП совпал с тангенсом"


def test_contour_length_grows_when_the_interval_shrinks():
    """Мельче сечение - длиннее суммарная линия горизонталей."""
    ny = nx = 80
    cell = 10.0
    y, _x = np.mgrid[0:ny, 0:nx]
    z = (y * 2.0).astype(float)
    mask = np.ones(z.shape, dtype=bool)
    fine = tg.contour_length_in_mask(z, mask, cell, 2.0)
    coarse = tg.contour_length_in_mask(z, mask, cell, 20.0)
    assert fine > coarse * 5


def test_sp_stream_matches_simple_slope_on_a_straight_profile():
    """На ровном профиле средневзвешенный уклон равен простому."""
    z = np.linspace(0.0, 100.0, 21)
    got = tg.sp_stream_ppm(z, 100.0)
    assert abs(got - 50.0) < 0.01


def test_sp_stream_is_lower_on_a_broken_profile():
    """У ломаного профиля СП даёт меньше простого отношения.

    Среднее геометрическое частных уклонов всегда не больше среднего
    арифметического, и в этом смысл методики: река с крутым верховьем и
    пологим низовьем не описывается одним отношением падения к длине.
    """
    z = np.concatenate([np.linspace(0.0, 80.0, 8),
                        np.linspace(80.0, 100.0, 14)[1:]])
    simple = (z[-1] - z[0]) / (100.0 * (len(z) - 1)) * 1000.0
    got = tg.sp_stream_ppm(z, 100.0)
    assert got < simple * 0.9, "%.2f против %.2f" % (got, simple)


def test_sp_fields_are_absent_without_an_interval():
    """Нулевое сечение - расчёт по СП не выполняется вовсе."""
    ny = nx = 40
    y, _x = np.mgrid[0:ny, 0:nx]
    z = (200.0 - y * 1.0).astype(float)
    mask = np.zeros(z.shape, dtype=bool)
    mask[5:35, 5:35] = True
    rep = tg.mask_report(z, mask, 100.0)
    assert rep.get("sp_slope_ppm") is None
    assert rep.get("sp_iso_km") is None
    with_iso = tg.mask_report(z, mask, 100.0, iso_interval=10.0)
    assert with_iso.get("sp_slope_ppm") is not None
