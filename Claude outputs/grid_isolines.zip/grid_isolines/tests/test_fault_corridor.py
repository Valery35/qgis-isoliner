# -*- coding: utf-8 -*-
#
# Isoliner - грид и изолинии (QGIS).
# © 2026 ООО «Информ++» (www.informpp.ru).
# SPDX-License-Identifier: GPL-2.0-or-later
#
"""Притяжка концов изолиний к разлому: поведение ядра.

История. Вдоль разлома грид сплошной, значения по разные стороны
отличаются на всю амплитуду, и скачок приходится на пару соседних ячеек.
Контурер рисует в этом промежутке все промежуточные уровни разом, поэтому
полоса вырезается коридором, а освободившиеся концы притягиваются к линии.

Первые две попытки притянуть их штатным native:snapgeometries дали на
карте веер: у затухающего конца разлома десяток концов сходился в одну
точку. Меняли форму торца коридора, вырезали кружок у конца - не
помогало, потому что дело было не в коридоре. Штатная притяжка тянет
конец к ближайшей точке опорного слоя без разбора, а за концом линии
такая точка одна на всех, сама концевая вершина.

Здесь проверяется ядро своей притяжки. Оно чистая математика, поэтому
берётся из исходника разбором AST и выполняется без QGIS.
"""
import ast
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(os.path.dirname(HERE), "isolines.py")


def _load(*names):
    """Взять функции из модуля, не импортируя его целиком.

    Берутся все названные разом в одно пространство имён: они зовут друг
    друга, и по одной их не выполнить.
    """
    with open(SRC, encoding="utf-8") as fh:
        tree = ast.parse(fh.read())
    wanted = {n: None for n in names}
    body = [node for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name in wanted]
    missing = [n for n in names if n not in [f.name for f in body]]
    assert not missing, "функции пропали из isolines.py: %s" % ", ".join(missing)
    ns = {"math": math}
    exec(compile(ast.Module(body, []), "<isolines>", "exec"), ns)
    return [ns[n] for n in names]


CLOSEST, ON_FAULT, EXTEND, TRIM = _load(
    "_closest_on_fault", "_on_fault", "_extend_ends_xy", "_trim_polyline",
    "_nearest_on_fault")[:4]

# Вертикальный разлом от начала координат вверх, затухающий на y = 1000.
FAULT = [[(0.0, 0.0), (0.0, 1000.0)]]
TOL = 270.0


def test_end_beside_the_line_snaps_by_the_normal():
    """Конец сбоку от линии идёт к своему месту, по нормали."""
    hit = CLOSEST(100.0, 500.0, FAULT, TOL)
    assert hit is not None
    assert abs(hit[0] - 0.0) < 1e-9
    assert abs(hit[1] - 500.0) < 1e-9


def test_ends_beside_the_line_do_not_share_one_node():
    """Соседние концы приходят в РАЗНЫЕ точки, а не в одну.

    Схождение в один узел и есть веер. Проверка прямая: два конца на
    разной высоте обязаны получить разные цели.
    """
    a = CLOSEST(80.0, 400.0, FAULT, TOL)
    b = CLOSEST(80.0, 460.0, FAULT, TOL)
    assert a is not None and b is not None
    assert math.hypot(a[0] - b[0], a[1] - b[1]) > 1.0


def test_end_past_the_fault_tip_is_left_alone():
    """За концом разлома конец не двигается вовсе.

    Главный сторож этой правки. Здесь ближайшей точкой была бы концевая
    вершина, и притяжка сводила бы к ней все окрестные концы.
    """
    assert CLOSEST(0.0, 1100.0, FAULT, TOL) is None
    assert CLOSEST(150.0, 1080.0, FAULT, TOL) is None
    assert CLOSEST(-120.0, 1050.0, FAULT, TOL) is None


def test_end_near_the_tip_but_beside_the_line_still_snaps():
    """Рядом с концом, но сбоку от линии, притяжка работает.

    Иначе лекарство от веера съело бы разрыв у самого конца разлома.
    """
    hit = CLOSEST(200.0, 950.0, FAULT, TOL)
    assert hit is not None
    assert abs(hit[1] - 950.0) < 1e-9


def test_far_end_is_not_pulled():
    """Дальше допуска не тянем: это чужая изолиния, а не край коридора."""
    assert CLOSEST(400.0, 500.0, FAULT, TOL) is None


def test_broken_fault_line_keeps_inner_vertices_live():
    """У ломаного разлома внутренние вершины концами не считаются.

    Отказ обязан касаться только двух концов ломаной. Внутренний излом -
    обычное место разрыва, и притяжка там нужна.
    """
    bent = [[(0.0, 0.0), (0.0, 500.0), (300.0, 800.0)]]
    hit = CLOSEST(60.0, 480.0, bent, TOL)
    assert hit is not None, "притяжка отказала у внутреннего излома"


def test_point_on_the_fault_is_recognised():
    """Точка на линии распознаётся, точка в стороне - нет.

    По этой проверке овершут решает, продлевать конец или оставить его на
    месте. Продлённый на разломе конец выносится на чужое крыло, достаёт
    до соседней изолинии и замыкает с ней лишнюю грань: на карте это
    тёмные полосы поперёк разлома при верно лежащих изолиниях.
    """
    assert ON_FAULT(0.0, 500.0, FAULT, 1.0)
    assert ON_FAULT(0.4, 500.0, FAULT, 1.0)
    assert not ON_FAULT(20.0, 500.0, FAULT, 1.0)


def test_overshoot_is_held_only_at_the_fault():
    """За концом разлома точка на линии не лежит, и овершут разрешён.

    Иначе изолинии, огибающие затухающий конец, лишились бы овершута на
    контуре области без всякой причины.
    """
    assert not ON_FAULT(0.0, 1100.0, FAULT, 1.0)


# --- овершут: продление открытых концов -----------------------------------

def test_both_tips_are_taken_from_the_original_ends():
    """Хвостики считаются от НАСТОЯЩИХ крайних вершин, обеих.

    Здесь была ошибка, стоившая части поясов. Вершины дописывались по
    очереди, и вставка в начало сдвигала индексы: второй хвостик уезжал
    от предпоследней точки, а приписывался к последней. На карте это
    чужой отрезок поперёк изолиний, в поясах - незамкнутые грани.

    Ломаная взята с изломом, чтобы направление у концов было разным и
    подмена вершины сразу читалась в числах.
    """
    pts = [(0.0, 0.0), (10.0, 0.0), (20.0, 10.0)]
    out = EXTEND(pts, 5.0, 5.0)
    assert len(out) == len(pts) + 2
    assert abs(out[0][0] - (-5.0)) < 1e-9
    assert abs(out[0][1] - 0.0) < 1e-9
    step = 5.0 / math.sqrt(2.0)
    assert abs(out[-1][0] - (20.0 + step)) < 1e-9
    assert abs(out[-1][1] - (10.0 + step)) < 1e-9
    assert out[1:-1] == pts


def test_each_end_gets_its_own_length():
    """Длина хвостика задаётся по концам отдельно.

    У контура области нужен хвостик в ячейку, у разлома короткий: там
    достаточно пересечь линию, чтобы стык занодировался, а длинный
    вынесет конец на чужое крыло и замкнёт лишнюю грань.
    """
    pts = [(0.0, 0.0), (10.0, 0.0)]
    out = EXTEND(pts, 1.0, 5.0)
    assert len(out) == 4
    assert abs(out[0][0] - (-1.0)) < 1e-9
    assert abs(out[-1][0] - 15.0) < 1e-9


def test_zero_length_means_no_tip():
    """Ноль означает не продлевать, и только этот конец."""
    pts = [(0.0, 0.0), (10.0, 0.0)]
    out = EXTEND(pts, 0.0, 5.0)
    assert len(out) == 3
    assert out[0] == pts[0]
    assert abs(out[-1][0] - 15.0) < 1e-9
    assert EXTEND(pts, 0.0, 0.0) == pts


def test_short_tip_at_the_fault_crosses_but_does_not_reach_the_other_wing():
    """Короткий хвостик пересекает разлом и не достаёт до чужой изолинии.

    Коридор вычистил полосу своей ширины по обе стороны, поэтому
    ближайшая чужая изолиния не ближе неё. Хвостик в десятую долю ячейки
    заведомо короче.
    """
    cell = 217.7
    corridor = cell
    short = cell * 0.1
    assert short > 0.0, "хвостик у разлома исчез"
    assert short < corridor, "хвостик у разлома достаёт до чужого крыла"


def test_closed_ring_is_left_alone():
    """Замкнутая петля не трогается: шпора внутрь поля плодит слайверы."""
    ring = [(0.0, 0.0), (10.0, 0.0), (10.0, 10.0), (0.0, 0.0)]
    assert EXTEND(ring, 5.0, 5.0) == ring


# --- укорочение оси коридора ----------------------------------------------

def test_trim_shortens_from_both_ends():
    """Ось коридора короче разлома на срез с каждой стороны.

    Полоса, доходящая до самого конца разлома, режет изолинии торцом, и
    обрезанный конец оказывается за концевой вершиной. Притянуть его
    нельзя, он остаётся висеть в стороне, и полигонизация выбрасывает его
    вместе со всем куском изолинии. Такая изолиния рисуется без границы
    пояса под ней.
    """
    pts = [(0.0, 0.0), (0.0, 1000.0)]
    out = TRIM(pts, 100.0)
    assert abs(out[0][1] - 100.0) < 1e-9
    assert abs(out[-1][1] - 900.0) < 1e-9


def test_trimmed_axis_keeps_the_cut_end_beside_the_line():
    """Обрезанный конец проецируется СТРОГО внутрь настоящего разлома.

    Это и есть смысл укорочения: конец у торца полосы лежит на уровне
    среза, то есть в стороне от линии, а не за её концом, и притяжка его
    берёт.
    """
    full = [[(0.0, 0.0), (0.0, 1000.0)]]
    cut = 100.0
    axis = TRIM(full[0], cut)
    # конец у торца полосы: на уровне среза, со сдвигом вбок на ширину
    end = (cut, axis[-1][1])
    assert CLOSEST(end[0], end[1], full, cut * 1.5) is not None, (
        "конец у торца коридора притянуть не удалось")


def test_trim_keeps_intermediate_vertices():
    """Внутренние вершины ломаной сохраняются, срезаются только концы."""
    pts = [(0.0, 0.0), (0.0, 500.0), (300.0, 500.0)]
    out = TRIM(pts, 50.0)
    assert (0.0, 500.0) in out, "излом потерян при укорочении"


def test_short_fault_is_not_trimmed_away():
    """Короткий разлом не исчезает: срез не больше трети длины."""
    pts = [(0.0, 0.0), (0.0, 30.0)]
    out = TRIM(pts, 100.0)
    assert len(out) >= 2
    length = math.hypot(out[-1][0] - out[0][0], out[-1][1] - out[0][1])
    assert length > 0.0, "разлом укоротили до точки"


# --- ось коридора у стыка --------------------------------------------------

AXIS, ABUTS = _load("_axis_for_corridor", "_abuts_other", "_trim_one_end",
                    "_extend_ends_xy", "_nearest_on_fault")[:2]

STEM = [(30.0, 0.0), (30.0, 30.0)]        # упирается в перекладину
BAR = [(0.0, 30.0), (60.0, 30.0)]         # оба конца свободны
W = 5.0
EPS = 0.25


def test_free_end_is_trimmed_and_abutting_end_is_extended():
    """Свободный конец укорачивается, примыкающий продлевается.

    Конец, лежащий на соседнем разломе, не затухающий: смещение там не
    сходит на нет, оно передаётся соседнему нарушению. Укоротить ось у
    такого конца значит оставить у стыка непрорезанный участок и пучок
    изолиний, которого там быть не должно.
    """
    axis = AXIS(STEM, [STEM, BAR], W, EPS)
    assert abs(axis[0][1] - W) < 1e-9, "свободный конец не укорочен"
    assert abs(axis[-1][1] - (30.0 + W)) < 1e-9, (
        "примыкающий конец не продлён за стык")


def test_both_free_ends_are_trimmed():
    """У линии без стыков укорачиваются оба конца, как прежде."""
    axis = AXIS(BAR, [STEM, BAR], W, EPS)
    assert abs(axis[0][0] - W) < 1e-9
    assert abs(axis[-1][0] - (60.0 - W)) < 1e-9


def test_lone_fault_is_trimmed_on_both_sides():
    """Одиночный разлом ведёт себя как раньше: оба конца свободны."""
    lone = [(10.0, 0.0), (10.0, 40.0)]
    axis = AXIS(lone, [lone], W, EPS)
    assert abs(axis[0][1] - W) < 1e-9
    assert abs(axis[-1][1] - (40.0 - W)) < 1e-9


def test_abutment_is_recognised_only_within_tolerance():
    """Недоведённый конец примыкающим не считается.

    Иначе щель в оцифровке молча превращалась бы в стык, и коридор
    прорезал бы то, что рвать там нечем.
    """
    short_stem = [(30.0, 0.0), (30.0, 29.0)]
    assert not ABUTS(short_stem, 1, [short_stem, BAR], EPS)
    assert ABUTS(STEM, 1, [STEM, BAR], EPS)


# --- чистка частей ---------------------------------------------------------

CLEAN = _load("_clean_parts", "_nearest_on_fault")[0]


def test_zero_length_part_is_dropped():
    """Кусок нулевой длины выбрасывается, а не роняет расчёт.

    Разрез линией разлома оставляет такие обрывки там, где линия проходит
    точно через вершину изолинии. Processing считает эту геометрию
    некорректной и прерывает расчёт целиком.
    """
    out, dropped = CLEAN([[(0.0, 0.0), (0.0, 0.0)]])
    assert out == [] and dropped == 1


def test_single_point_part_is_dropped():
    out, dropped = CLEAN([[(1.0, 2.0)]])
    assert out == [] and dropped == 1


def test_duplicate_nodes_are_removed_but_line_survives():
    """Совпадающие соседние узлы снимаются, сама линия остаётся."""
    out, dropped = CLEAN([[(0.0, 0.0), (0.0, 0.0), (10.0, 0.0)]])
    assert dropped == 0
    assert out == [[(0.0, 0.0), (10.0, 0.0)]]


def test_good_parts_pass_through_unchanged():
    parts = [[(0.0, 0.0), (10.0, 0.0)], [(0.0, 5.0), (10.0, 5.0)]]
    out, dropped = CLEAN(parts)
    assert dropped == 0 and out == parts


def test_mixed_input_keeps_only_the_good_parts():
    """Из мультичасти выбрасывается только вырожденная часть."""
    out, dropped = CLEAN([[(0.0, 0.0), (10.0, 0.0)], [(5.0, 5.0), (5.0, 5.0)]])
    assert dropped == 1
    assert out == [[(0.0, 0.0), (10.0, 0.0)]]
